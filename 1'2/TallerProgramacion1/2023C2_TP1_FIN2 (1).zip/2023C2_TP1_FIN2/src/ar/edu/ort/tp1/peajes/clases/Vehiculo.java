package ar.edu.ort.tp1.peajes.clases;

public abstract class Vehiculo {
	private static final String MSG_ERROR_PESO    = "El Peso del vehiculo debe ser mayor a 0.";
	private static final String MSG_ERROR_PATENTE = "La patente no puede ser nula ni estar vacia.";
	// TODO A completar
	
	public Vehiculo(String patente, int pesoEnKilos) {
		// TODO A completar
	}

	@Override
	public String toString() {
		return "Vehiculo (" + this.getClass().getSimpleName() + ") [patente=" + patente + ", pesoEnKilos=" + pesoEnKilos + "]";
	}
	
	
}
