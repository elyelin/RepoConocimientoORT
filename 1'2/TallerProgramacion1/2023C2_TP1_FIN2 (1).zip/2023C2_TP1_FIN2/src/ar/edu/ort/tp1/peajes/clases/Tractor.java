package ar.edu.ort.tp1.peajes.clases;

public class Tractor extends Vehiculo {
	
	// TODO A completar
	
	public Tractor(String patente, int pesoEnKilos) {
		super(patente, pesoEnKilos);
	}
	
}
