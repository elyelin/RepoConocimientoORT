package ar.edu.ort.tp1.peajes.clases;

public class Motocicleta extends Vehiculo {
	private static final String MSG_ERROR_CILINDRADA = "La cilindrade debe ser un numero positivo menor que 5000.";
	private static final int MAX_CILINDRADA = 5000;
	private static final int IMPORTE_BASE = 100;
	
	// TODO A completar
	
}
