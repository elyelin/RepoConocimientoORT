package ar.edu.ort.tp1.peajes.clases;

public class Camion extends Vehiculo {
	private static final int IMPORTE_BASE = 500;
	
	// TODO A completar
	
	
}
