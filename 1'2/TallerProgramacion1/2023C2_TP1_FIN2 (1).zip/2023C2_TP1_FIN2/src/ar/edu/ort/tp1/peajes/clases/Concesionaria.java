package ar.edu.ort.tp1.peajes.clases;

public class Concesionaria  {
	private static final String MSG_PORTICO_AGREGADO 	= "Se ha agregado el pórtico [%s]";
	private static final String MSG_ERROR_NOMBRE_CONCESIONARIA = "El nombre de la concesionaria no puede ser nulo ni estar vacío.";
	private static final String MSG_ERROR_PORTICO_INEXISTENTE  = "El pórtico [%s] no existe.";
	private static final String MSG_ERROR_PROCESANDO_VEHICULO  = "Error procesando el vehículo [%s].";
	// TODO A completar

	public Concesionaria(String nombre) {
		// TODO A completar
	}
	
	/**
	 * Este metodo agrega el portico a la concesionaria.
	 * @param nombre
	 */
	public void agregarPortico(String nombre) {
		// TODO A completar
		
		System.out.println(String.format(MSG_PORTICO_AGREGADO, nombre));
	}
	
	/**
	 * Procesar el vehiculo en el portico especificado.
	 * Si el portico es inexistente o el proceso falla, se debe almacenar el error.
	 * @param nombrePortico es el nombre del Portico por donde paso el vehiculo,
	 * @param vehiculo es el vehiculo a procesar.
	 * @param carril es el carril (sensor) por el que paso el vehiculo.
	 */
	public void procesarVehiculo(String nombrePortico, Vehiculo vehiculo, int carril) {
		// TODO A completar
		// Utilizar estas constantes
		//	MSG_ERROR_PORTICO_INEXISTENTE
		//	MSG_ERROR_PROCESANDO_VEHICULO
	}
	
	/**
	 * Muestra por consola los errores recolectados según su orden cronológico de aparición.
	 */
	private void mostrarErrores() {
		// TODO A completar
		System.out.println("\n--------------- MOSTRAR ERRORES ---------------");
	}
	
	/**
	 * Muestra por consola las estadisticas de cada uno de los porticos, ordenado por nombre de portico.
	 */
	private void mostrarEstadisticasPorticos() {
		// TODO A completar
		System.out.println("\n--------------- MOSTRAR ESTADISTICAS PORTICOS ---------------");
	}

	@Override
	public void mostrarEstadisticas() {
		mostrarEstadisticasPorticos();
		mostrarErrores();
	}
}
