package ar.edu.ort.tp1.peajes.clases;

public class Automovil extends Vehiculo {
	private static final int IMPORTE_BASE = 250;

	// TODO A completar
	
	
}
