package ar.edu.ort.tp1.final1.clases;

public class Piso {

	private static final int MINIMA_CAPACIDAD_MAXIMA = 2;
//	TODO COMPLETAR
	
	public Piso(int capacidadMaxima) {
//		TODO COMPLETAR
	}

}
