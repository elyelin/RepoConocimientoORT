package ar.edu.ort.tp1.final1.clases;

public class Estacionamiento implements EspacioInteligente<Vehiculo, String> {

	private static final int CANTIDAD_PISOS_MIN = 2;
	private String nombre;
//	TODO COMPLETAR

	public Estacionamiento(String nombre, int cantPisos, int capacidadPiso) {
		this.nombre = nombre;
//		TODO COMPLETAR
	}

	public void ...() {
		System.out.println("Estadísticas del garaje: " + nombre);
		System.out.println("Motos estacionadas por patente:");
//		TODO COMPLETAR
	}
}
