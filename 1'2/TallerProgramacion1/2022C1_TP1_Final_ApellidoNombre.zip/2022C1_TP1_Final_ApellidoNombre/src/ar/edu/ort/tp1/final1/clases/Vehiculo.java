package ar.edu.ort.tp1.final1.clases;

public abstract class Vehiculo {

	private String patente;
	private String marca;
	private String modelo;
	

	public Vehiculo(String patente, String marca, String modelo) {
		//TODO Completar
	}
	
	

	public boolean coincidePatente(String id) {
		return this.patente.equals(id);
	}

}
