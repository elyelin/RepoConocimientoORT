package ar.edu.ort.tp1.final1.clases;

public interface Mostrable {

	public void mostrar();
}
