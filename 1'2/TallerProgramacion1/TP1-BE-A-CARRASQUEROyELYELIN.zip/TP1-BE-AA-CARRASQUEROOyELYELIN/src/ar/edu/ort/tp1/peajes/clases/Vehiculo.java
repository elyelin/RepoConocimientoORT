package ar.edu.ort.tp1.peajes.clases;

public abstract class Vehiculo {
	private static final String MSG_ERROR_PESO    = "El Peso del vehiculo debe ser mayor a 0.";
	private static final String MSG_ERROR_PATENTE = "La patente no puede ser nula ni estar vacia.";
	private String patente;
	private int peso;
	
	public Vehiculo(String patente, int pesoEnKilos) {
		setPatente(patente);
		setPeso(pesoEnKilos);
	}

	@Override
	public String toString() {
		return "Vehiculo (" + this.getClass().getSimpleName() + ") [patente=" + patente + ", pesoEnKilos=" + peso + "]";
	}
	
	public String getPatente() {
		return patente;
	}

	public int getPeso() {
		return peso;
	}

	private void setPatente(String patente) {
		if (patente == null || patente.isEmpty()) {
			throw new IllegalArgumentException(MSG_ERROR_PATENTE);
		}
		this.patente = patente;
	}

	private void setPeso(int peso) {
		if (peso < 0) {
			throw new IllegalArgumentException(MSG_ERROR_PESO);
		}
		this.peso = peso;
	}
	
    public abstract float calcularImporte();

}