package ar.edu.ort.tp1.peajes.clases;

public class Motocicleta extends Vehiculo {

	private static final String MSG_ERROR_CILINDRADA = "La cilindrade debe ser un numero positivo menor que 5000.";
	private static final int MAX_CILINDRADA = 5000;
	private static final int IMPORTE_BASE = 100;
	private int cilindrada;
	

	public Motocicleta(String patente, int pesoEnKilos, int cilindrada) {
		super(patente, pesoEnKilos);
		setCilindrada(cilindrada);
	}

	private void setCilindrada(int cilindrada) {
		if (cilindrada < 0 || cilindrada > MAX_CILINDRADA) {
			throw new IllegalArgumentException(MSG_ERROR_CILINDRADA);
		}
		this.cilindrada = cilindrada;
	}

	@Override
	public float calcularImporte() {
		if (cilindrada < 1500) {
			return IMPORTE_BASE + IMPORTE_BASE / 2;
		} else {
			return IMPORTE_BASE + IMPORTE_BASE;
		}
	}
}
