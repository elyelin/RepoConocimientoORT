package ar.edu.ort.tp1.tdas.interfaces;

public interface Sizeable {

	int size();

}