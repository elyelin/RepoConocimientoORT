package ar.edu.ort.tp1.peajes.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Cola;

public class Sensor {
	private static final String MSG_ERROR_TIPO_VEHICULO_INCORRECTO = "El tipo de vehículo [%s] no está soportado por la plataforma.";
	private Cola<Vehiculo> vehiculosProcesados;

	public Sensor() {
		this.vehiculosProcesados = new ColaNodos<>();
	}

	/**
	 * Retorna true en el caso de que el vehiculo sea un Automovil, Camion o
	 * Motocicleta, sino retorna false.
	 *
	 * @param v el vehiculo.
	 * @return true en el caso de que el vehiculo sea un Automovil, Camion o
	 *         Motocicleta, sino retorna false.
	 */
	private boolean isClaseVehiculoSoportada(Vehiculo v) {
		return v instanceof Automovil || v instanceof Camion || v instanceof Motocicleta;
	}

	/**
	 * Procesa el vehiculo y retorna el importe. En caso de que la clase no sea
	 * "soportada" arroja una Exception con el mensaje
	 * MSG_ERROR_TIPO_VEHICULO_INCORRECTO.
	 *
	 * @param v Vehiculo a procesar
	 * @return el Importe del peaje.
	 * @throws IllegalArgumentException Si el tipo de vehículo no está soportado.
	 */
	public float procesarVehiculoRetornarImporte(Vehiculo v) throws IllegalArgumentException {
		if (!isClaseVehiculoSoportada(v)) {
			throw new IllegalArgumentException(
					String.format(MSG_ERROR_TIPO_VEHICULO_INCORRECTO, v.getClass().getSimpleName()));
		}

		float importe = v.calcularImporte();
		vehiculosProcesados.add(v);
		return importe;
	}

	/**
	 * Este método retorna el importe total acumulado de los vehículos que fueron
	 * procesados por el Sensor. Este método no elimina los elementos de la
	 * colección.
	 *
	 * @return el importe total acumulado de los vehículos que fueron procesados por
	 *         el Sensor.
	 */
	public float getImporteProcesados() {
		float importeTotal = 0;

		ColaNodos<Vehiculo> copiaCola = new ColaNodos<>();

		while (!vehiculosProcesados.isEmpty()) {
			Vehiculo vehiculo = vehiculosProcesados.remove();
			importeTotal += vehiculo.calcularImporte();
			copiaCola.add(vehiculo);
		}

		while (!copiaCola.isEmpty()) {
			vehiculosProcesados.add(copiaCola.remove());
		}

		return importeTotal;
	}

	/**
	 * Este método retorna la cantidad de vehículos que fueron procesados por el
	 * Sensor. Este método no elimina los elementos de la colección.
	 *
	 * @return la cantidad de vehículos que fueron procesados por el Sensor.
	 */
	public int getCantidadProcesados() {
		int cantidad = 0;

		ColaNodos<Vehiculo> copiaCola = new ColaNodos<>();

		while (!vehiculosProcesados.isEmpty()) {
			Vehiculo vehiculo = vehiculosProcesados.remove();
			cantidad++;
			copiaCola.add(vehiculo);
		}

		while (!copiaCola.isEmpty()) {
			vehiculosProcesados.add(copiaCola.remove());
		}

		return cantidad;
	}
}