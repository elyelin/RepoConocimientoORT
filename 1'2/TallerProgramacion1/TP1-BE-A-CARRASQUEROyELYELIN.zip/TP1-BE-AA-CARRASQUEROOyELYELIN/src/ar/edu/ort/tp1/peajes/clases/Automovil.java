package ar.edu.ort.tp1.peajes.clases;

public class Automovil extends Vehiculo {
	private static final int IMPORTE_BASE = 250;
	private static final int IMPORTE_ADICIONAL = 0;

	public Automovil(String patente, int pesoEnKilos) {
		super(patente, pesoEnKilos);
	}

	@Override
	public float calcularImporte() {
		return IMPORTE_BASE + IMPORTE_ADICIONAL;
	}
}