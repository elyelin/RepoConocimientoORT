package ar.edu.ort.tp1.peajes.clases;

public class Camion extends Vehiculo {

	private static final int IMPORTE_BASE = 500;
	private static final int IMPORTE_ADICIONAL = 0;
	private TipoDeAcoplado tipo;


	public Camion(String patente, int pesoEnKilos, TipoDeAcoplado tipo) {
		super(patente, pesoEnKilos);
		this.tipo = tipo;
	}

	@Override
	public float calcularImporte() {
		return IMPORTE_BASE * tipo.getMultiplicadorTipoDeAcoplado();
	}
}