package ar.edu.ort.tp1.peajes.clases;

public class Tractor extends Vehiculo {

	public Tractor(String patente, int pesoEnKilos) {
		super(patente, pesoEnKilos);
	}

	@Override
	public float calcularImporte() {
		// El importe para tractores es despreciable (o regalado)
		return 0;
	}
}