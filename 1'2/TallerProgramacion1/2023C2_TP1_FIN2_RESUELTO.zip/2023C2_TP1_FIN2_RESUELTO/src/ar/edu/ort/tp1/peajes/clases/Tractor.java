package ar.edu.ort.tp1.peajes.clases;

public class Tractor extends Vehiculo{
	
	public Tractor(String patente, int pesoEnKilos) {
		super(patente, pesoEnKilos);
	}
	
	@Override
	public boolean isPatenteValida(String patente) {
		return true;
	}

	@Override
	public int getImporteBase() {
		return  0;
	}

	@Override
	public float getImporteAdicional() {
		return 0;
	}
}
