package ar.edu.ort.tp1.peajes.clases;

public interface Mostrable {
	void mostrarEstadisticas();
}
