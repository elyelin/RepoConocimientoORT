package ar.edu.ort.tp1.peajes.clases;

public abstract class Vehiculo {
	private static final String MSG_ERROR_PESO    = "El Peso del vehiculo debe ser mayor a 0.";
	private static final String MSG_ERROR_PATENTE = "La patente no puede ser nula ni estar vacia.";
	
	
	private String patente;
	private int pesoEnKilos;
	
	public abstract boolean isPatenteValida (String patente);
	public abstract int getImporteBase ();
	public abstract float getImporteAdicional ();
	// 
	public float calcularImporteDelPeaje() {
		return getImporteBase() + getImporteAdicional();
	}
	
	public Vehiculo(String patente, int pesoEnKilos) {
		setPatente(patente);
		setPesoEnKilos(pesoEnKilos);
	}

	public String getPatente() {
		return patente;
	}

	public void setPatente(String patente) {
		if (!isPatenteValida(patente)) {
			throw new IllegalArgumentException(MSG_ERROR_PATENTE);
		}
		this.patente = patente;
	}

	public int getPesoEnKilos() {
		return pesoEnKilos;
	}

	public void setPesoEnKilos(int pesoEnKilos) {
		if (pesoEnKilos < 0) {
			throw new IllegalArgumentException(MSG_ERROR_PESO);
		}
		this.pesoEnKilos = pesoEnKilos;
	}
	@Override
	public String toString() {
		return "Vehiculo (" + this.getClass().getSimpleName() + ") [patente=" + patente + ", pesoEnKilos=" + pesoEnKilos + "]";
	}
	
	
}
