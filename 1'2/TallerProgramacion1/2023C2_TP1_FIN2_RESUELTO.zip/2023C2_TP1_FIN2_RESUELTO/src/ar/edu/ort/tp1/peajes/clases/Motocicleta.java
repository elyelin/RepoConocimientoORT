package ar.edu.ort.tp1.peajes.clases;

public class Motocicleta extends Vehiculo{
	private static final String MSG_ERROR_CILINDRADA = "La cilindrade debe ser un numero positivo menor que 5000.";
	private static final int MAX_CILINDRADA = 5000;
	private static final int IMPORTE_BASE = 100;
	private int cilindrada;
	
	public Motocicleta(String patente, int pesoEnKilos, int cilindrada) {
		super(patente, pesoEnKilos);
		setCilindrada(cilindrada);
	}

	public int getCilindrada() {
		return cilindrada;
	}

	public void setCilindrada(int cilindrada) {
		if ((cilindrada < 0) || (cilindrada > MAX_CILINDRADA )) {
			throw new IllegalArgumentException(MSG_ERROR_CILINDRADA);
		}
		this.cilindrada = cilindrada;
	}
	
	@Override
	public boolean isPatenteValida(String patente) {
		// La patente de una motocicleta tiene que tener exactamente 4 (letras/números/etc.)
		//	y comenzar con una 'A'.
		//	Por ejemplo "A123", "A A5", "A%%%" o "AA66".
		boolean retornar = false;
	
		if (patente != null) {
			if (patente.length() == 4) {
				retornar = true;
			}
		}
		return retornar;
	}

	@Override
	public int getImporteBase() {
		return  IMPORTE_BASE;
	}

	@Override
	public float getImporteAdicional() {
		// Si la cilindrada de la Motocicleta es menor a 1500, se le adiciona la mitad del 
		//	importe base de la motocicleta.
		// Si es Mayor o igual se adiciona la totalidad del importe base de la motocicleta.
		//
		float valorAdicional = 0;
		if (getCilindrada() < 1500) {
			valorAdicional = getImporteBase() / 2;
		} else {
			valorAdicional = getImporteBase();
		}
		return valorAdicional;
	}
}
