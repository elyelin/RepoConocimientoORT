package ar.edu.ort.tp1.peajes.clases;

public class Camion extends Vehiculo {
	private static final int IMPORTE_BASE = 500;
	private TipoDeAcoplado tipoDeAcoplado;
	
	public Camion(String patente, int pesoEnKilos, TipoDeAcoplado tipoDeAcoplado) {
		super(patente, pesoEnKilos);
		setTipoDeAcoplado(tipoDeAcoplado);
	}

	public TipoDeAcoplado getTipoDeAcoplado() {
		return tipoDeAcoplado;
	}

	public void setTipoDeAcoplado(TipoDeAcoplado tipoDeAcoplado) {
		this.tipoDeAcoplado = tipoDeAcoplado;
	}
	
	@Override
	public boolean isPatenteValida(String patente) {
		// La patente de un camion tiene que tener mas de 6 caracteres (letras/numeros/etc...) y 
		//	debe contener al menos un espacio " ".
		//	Por ejemplo "AAA 112 11", "14 23456" o "ABCDE F5".
		boolean retornar = false;
	
		if (patente != null) {
			if ((patente.length() > 6) && (patente.contains(" "))) {
				retornar = true;
			}
		}
		return retornar;
	}

	@Override
	public int getImporteBase() {
		return IMPORTE_BASE;
	}

	@Override
	public float getImporteAdicional() {
		// El adicional es igual al Importe base, 
		//	multiplicado por el tipo de multiplicador del Acoplado. 
		// 
		float valorAdicional = 0;
		valorAdicional = getImporteBase() + getTipoDeAcoplado().getMultiplicadorTipoDeAcoplado();
		return valorAdicional;
	}
}
