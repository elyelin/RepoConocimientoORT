package ar.edu.ort.tp1.peajes.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ColaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Cola;

public class Sensor {
	private static final String MSG_ERROR_TIPO_VEHICULO_INCORRECTO = "El tipo de vehículo [%s] no está soportado por la plataforma.";
	
	private Cola<Vehiculo> 	vehiculos;
	/*
	 * Valores esperables en la mejor resolucion
	 */
	// private float 			importeProcesados;
	// private int  			cantidadProcesados;

	public Sensor() {
		vehiculos 			= new ColaNodos<Vehiculo>();
		/*
		 * Valores esperables en la mejor resolucion
		 */
		// importeProcesados 	= 0;
		// cantidadProcesados	= 0;
	}
	
	/**
	 * Retorna true en el caso de que el vehiculo sea un Automovil, Camion o Motocicleta, sino retorna false.
	 * @param v el vehiculo.
	 * @return true en el caso de que el vehiculo sea un Automovil, Camion o Motocicleta, sino retorna false.
	 */
	private boolean isClaseVehiculoSoportada(Vehiculo v) {
		boolean retornar = false;
		if (v!=null) {
			if ((v instanceof Automovil) ||
				(v instanceof Camion) ||
				(v instanceof Motocicleta)) {
				retornar = true;
			}
		}
		return retornar;
	}
	
	/**
	 * Procesa el vehiculo y retorna el importe.
	 * En caso de que la clase no sea "soportada" arroja una Exception 
	 *  con el mensaje MSG_ERROR_TIPO_VEHICULO_INCORRECTO.
	 * @param v Vehiculo a procesar
	 * @return el Importe del peaje.
	 */
	public float procesarVehiculoRetornarImporte(Vehiculo v) {
		// TODO A completar
		float importe = 0;
		
		if (!isClaseVehiculoSoportada(v)) {
			throw new IllegalArgumentException(String.format(MSG_ERROR_TIPO_VEHICULO_INCORRECTO, v.getClass().getSimpleName()));
		}
	
		vehiculos.add(v);
		importe = v.calcularImporteDelPeaje();
		
		// Si se avivan...
		//importeProcesados +=importe;
		//cantidadProcesados++;
			
		return importe;
	}
	
	/**
	 * Este metodo retorna el importe total acumulado de los vehiculos que fueron procesados por el Sensor.
	 * Este metodo no elimina los elementos de la coleccion.
	 * @return el importe total acumulado de los vehiculos que fueron procesados por el Sensor.
	 */
	public float getImporteProcesados() {
		// TODO A completar
		float 		importe = 0;
		Vehiculo 	centinela = null;
		Vehiculo 	vehiculoActual;
		
		vehiculos.add(centinela);
		vehiculoActual = vehiculos.remove();
		while (vehiculoActual != centinela) {
			importe += vehiculoActual.calcularImporteDelPeaje();
			vehiculos.add(vehiculoActual);
			vehiculoActual = vehiculos.remove();
		}
		
		return importe;
	}

	/*
	 * Resolucion deseable, simplificada
	 */
//	public float getImporteProcesados() {
//		return importeProcesados;
//	}
	
	/**
	 * Este metodo retorna la cantidad de vehiculos que fueron procesados por el Sensor.
	 * Este metodo no elimina los elementos de la coleccion.
	 * @return la cantidad de vehiculos que fueron procesados por el Sensor.
	 */
	public int getCantidadProcesados() {
		// TODO A completar
		int 		cantidad = 0;
		Vehiculo 	centinela = null;
		Vehiculo 	vehiculoActual;
		
		vehiculos.add(centinela);
		vehiculoActual = vehiculos.remove();
		while (vehiculoActual != centinela) {
			cantidad++;
			vehiculos.add(vehiculoActual);
			vehiculoActual = vehiculos.remove();
		}
		
		return cantidad;
	}
	
	/*
	 * Resolucion deseable, simplificada
	 */
//	public int getCantidadProcesados() {
//		return cantidadProcesados;
//	}
}
