package ar.edu.ort.tp1.peajes.clases;

public class Automovil extends Vehiculo{
	private static final int IMPORTE_BASE = 250;
	
	public Automovil(String patente, int pesoEnKilos) {
		super(patente, pesoEnKilos);
		// TODO Auto-generated constructor stub
	}

	@Override
	public boolean isPatenteValida(String patente) {
		// La patente de un automovil tiene que tener exactamente 6 caracteres (letras/números/etc.).
		//	Por ejemplo "AAA111", "123456", "ABCDEF" o "1+^H2%"
		boolean retornar = false;
	
		if (patente != null) {
			if (patente.length() == 6) {
				retornar = true;
			}
		}
		return retornar;
	}

	@Override
	public int getImporteBase() {
		return IMPORTE_BASE;
	}

	@Override
	public float getImporteAdicional() {
		return 0;
	}
	
	
}
