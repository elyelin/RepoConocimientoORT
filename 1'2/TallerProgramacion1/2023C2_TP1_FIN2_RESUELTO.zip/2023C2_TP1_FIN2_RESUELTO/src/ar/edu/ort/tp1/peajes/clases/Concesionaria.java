package ar.edu.ort.tp1.peajes.clases;

import ar.edu.ort.tp1.tdas.implementaciones.PilaNodos;
import ar.edu.ort.tp1.tdas.interfaces.Pila;

public class Concesionaria implements Mostrable {
	private static final String MSG_PORTICO_AGREGADO 	= "Se ha agregado el pórtico [%s]";
	private static final String MSG_ERROR_NOMBRE_CONCESIONARIA = "El nombre de la concesionaria no puede ser nulo ni estar vacío.";
	private static final String MSG_ERROR_PORTICO_INEXISTENTE  = "El pórtico [%s] no existe.";
	private static final String MSG_ERROR_PROCESANDO_VEHICULO  = "Error procesando el vehículo [%s].";
	private String 			nombre;
	private Pila<String> 	pilaErrores;
	private ListaDePorticosOrdenadaPorNombre porticos;
	

	public Concesionaria(String nombre) {
		// TODO A completar
		setNombre(nombre);
		porticos = new ListaDePorticosOrdenadaPorNombre();
		pilaErrores	 = new PilaNodos<String>();
	}
	
	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		if (nombre==null || nombre.length()==0) {
			throw new IllegalArgumentException(MSG_ERROR_NOMBRE_CONCESIONARIA);
		}
		this.nombre = nombre;
	}
	
	/**
	 * Este metodo agrega el portico a la concesionaria.
	 * @param nombre
	 */
	public void agregarPortico(String nombre) {
		// TODO A completar
		Portico p = new Portico(nombre);
		porticos.add(p);
		
		System.out.println(String.format(MSG_PORTICO_AGREGADO, nombre));
	}
	
	/**
	 * Procesar el vehiculo en el portico especificado.
	 * Si el portico es inexistente o el proceso falla, se debe almacenar el error.
	 * @param nombrePortico es el nombre del Portico por donde paso el vehiculo,
	 * @param vehiculo es el vehiculo a procesar.
	 * @param carril es el carril (sensor) por el que paso el vehiculo.
	 */
	public void procesarVehiculo(String nombrePortico, Vehiculo vehiculo, int carril) {
		// TODO A completar
		Portico p;
		
		p = porticos.search(nombrePortico);
		if (p != null) {
			try {
				p.procesarVehiculo(vehiculo, carril);
			} catch(Exception ex) {
				pilaErrores.push(String.format(MSG_ERROR_PROCESANDO_VEHICULO, ex.getMessage()));
			}
		} else {
			pilaErrores.push(String.format(MSG_ERROR_PORTICO_INEXISTENTE, nombrePortico));
		}
	}
	
	/**
	 * Muestra por consola los errores recolectados según su orden cronológico de aparición.
	 */
	private void mostrarErrores() {
		// TODO A completar
		Pila<String> pilaAux = new PilaNodos<String>();
		String 		 errorActual;
		
		System.out.println("\n--------------- MOSTRAR ERRORES ---------------");
		while (!pilaErrores.isEmpty()) {
			pilaAux.push(pilaErrores.pop());
		}
		
		while (!pilaAux.isEmpty()) {
			errorActual = pilaAux.pop();
			System.out.println("ERROR: " + errorActual);
			pilaErrores.push(errorActual);
		}
	}
	
	/**
	 * Muestra por consola las estadisticas de cada uno de los porticos, ordenado por nombre de portico.
	 */
	private void mostrarEstadisticasPorticos() {
		// TODO A completar
		System.out.println("\n--------------- MOSTRAR ESTADISTICAS PORTICOS ---------------");
		for (Portico portico : porticos) {
			portico.mostrarEstadisticas();
		}
	}

	@Override
	public void mostrarEstadisticas() {
		mostrarEstadisticasPorticos();
		mostrarErrores();
	}
}
