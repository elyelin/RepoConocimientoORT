package ar.edu.ort.tp1.peajes.clases;

import ar.edu.ort.tp1.tdas.implementaciones.ListaOrdenadaNodos;

public class ListaDePorticosOrdenadaPorNombre extends ListaOrdenadaNodos <String, Portico> {

	@Override
	public int compare(Portico dato1, Portico dato2) {
		// TODO Auto-generated method stub
		return dato1.getNombre().compareTo(dato2.getNombre());
	}

	@Override
	public int compareByKey(String clave, Portico elemento) {
		// TODO Auto-generated method stub
		return clave.compareTo(elemento.getNombre());
	}
}
