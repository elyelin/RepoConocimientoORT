package parcialP1;

import java.util.ArrayList;

public class Ventana extends Componente {
	private Estado estado;
	private ArrayList<Componente> componentes;

	public Ventana(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado, Estado estado) {
		super(text, ejeXejeY, ancho, alto, color, hibilitado);
		this.estado = estado;
		this.componentes = new ArrayList<Componente>();
	}

	@Override
	public void dibujar() {
		System.out.println("Dibujando Ventana con los siguientes componentes: ");
		for (Componente c : componentes) {
			if (c instanceof CampoTexto) {
				((CampoTexto) c).activarCursor();
				((CampoTexto) c).dibujar();
			} else {
				c.dibujar();
			}
			// String resultado = c instanceof CampoTexto ? ((CampoTexto) c).activarCursor()
			// : c.dibujar();
		}
	}

	public boolean agregar(Componente c) {
		boolean salida = false;

		if (!(c instanceof Ventana)) {
			componentes.add(c);
			salida = true;
		}
		return salida;
	}

}
