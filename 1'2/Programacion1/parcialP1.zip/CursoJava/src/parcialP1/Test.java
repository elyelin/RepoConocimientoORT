package parcialP1;

public class Test {

	public static void main(String[] args) {
		Etiqueta et = new Etiqueta("etiqueta", 80, 200, 150, "azul", true, "roboto");
		Boton bt = new Boton("boton", 80, 200, 150, "azul", true);
		Ventana vt = new Ventana("ventana", 80, 200, 150, "azul", true, Estado.ABIERTA);
		CampoTexto ct = new CampoTexto("", 80, 200, 150, "azul", true, "jojjkjdjfhdjhfjdfhdfhdfd", true);
		VentanaError v = new VentanaError("ventana error", 80, 200, 150, "azul", true, Estado.ABIERTA);

		System.out.println(vt.agregar(bt));
		System.out.println(vt.agregar(ct));
		et.dibujar();
		bt.dibujar();
		vt.dibujar();
		ct.dibujar();

	}

}
