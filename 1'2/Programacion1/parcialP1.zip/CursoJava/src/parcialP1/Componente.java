package parcialP1;

public abstract class Componente {
	private String text;
	private int ejeXejeY;
	private int ancho;
	private int alto;
	private String color;
	private boolean hibilitado;

	public Componente(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado) {
		this.text = text;
		this.ejeXejeY = ejeXejeY;
		this.ancho = ancho;
		this.alto = alto;
		this.color = color;
		this.hibilitado = hibilitado;
	}

	public Componente(String nombre) {
		this.text = nombre;
	}

	public abstract void dibujar();

	public String getText() {
		return text;
	}

	public void setText(String n) {
		this.text = n;
	}

	public int getEjeXejeY() {
		return ejeXejeY;
	}

	public int getAncho() {
		return ancho;
	}

	public String getColor() {
		return color;
	}

	public boolean isHibilitado() {
		return hibilitado;
	}

	public int getAlto() {
		return alto;
	}


}
