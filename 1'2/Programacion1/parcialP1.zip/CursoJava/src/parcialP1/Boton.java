package parcialP1;

public class Boton extends Componente {

	public Boton(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado) {
		super(text, ejeXejeY, ancho, alto, color, hibilitado);
	}

	public Boton(String nombre) {
		super(nombre);
	}

	@Override
	public void dibujar() {
		System.out.println("Dibujando Boton con el texto: " + super.getText() + " con un alto de: " + super.getAncho()
				+ "mm y ancho de: " + super.getAncho());
	}

}
