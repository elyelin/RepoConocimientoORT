package parcialP1;

public class VentanaError extends Ventana {
	private Etiqueta etiqueta;
	private Boton boton;

	public VentanaError(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado, Estado estado) {
		super(text, ejeXejeY, ancho, alto, color, hibilitado, estado);
		this.etiqueta = new Etiqueta(color, ejeXejeY, ancho, alto, color, hibilitado, color);
		this.boton = new Boton("Aceptar");
	}

}
