package parcialP1;

public enum Estado {
	MINIMIZADA, MAXIMIZADO, CERRADA, ABIERTA
}
