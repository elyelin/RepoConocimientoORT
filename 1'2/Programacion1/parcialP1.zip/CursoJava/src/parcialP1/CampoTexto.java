package parcialP1;

public class CampoTexto extends Componente {
	private String multitexto;
	private boolean cursor;

	public CampoTexto(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado,
			String multitexto, boolean cursor) {
		super(text, ejeXejeY, ancho, alto, color, hibilitado);
		this.multitexto = multitexto;
		this.cursor = cursor;
	}

	@Override
	public void dibujar() {
		String textoMsj;
		
		// String t = super.getText().isEmpty() ? textoMsj = this.multitexto : textoMsj
		// = super.getText();
		 
		 if(super.getText().isEmpty()) {
			  textoMsj = this.multitexto;
		 }else {
			 textoMsj = super.getText();
		 }
		
			System.out.println("Dibujando Campo de Texto " + textoMsj + "que tiene el cursor" + this.cursor);
	}

	public void activarCursor() {
		this.cursor = true;
	}
}
