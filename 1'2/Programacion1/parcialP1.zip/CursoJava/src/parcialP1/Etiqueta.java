package parcialP1;

public class Etiqueta extends Componente {
	private String fuente;

	public Etiqueta(String text, int ejeXejeY, int ancho, int alto, String color, boolean hibilitado, String fuente) {
		super(text, ejeXejeY, ancho, alto, color, hibilitado);
		this.fuente = fuente;
	}

	public void dibujar() {
		System.out.println(
				"Dibujando Etiqueta con el texto " + super.getText() + " con fuente " + this.fuente);
	}
}
