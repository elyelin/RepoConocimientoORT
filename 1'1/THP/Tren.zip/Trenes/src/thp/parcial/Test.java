package thp.parcial;

public class Test {

	public static void main(String[] args) {
		Empresa emp = new Empresa();
		
		int tren1 = emp.crearFormacion();
		System.out.println("crearFormacion(): " + tren1);
		
		int tren2 = emp.crearFormacion();
		System.out.println("crearFormacion(): " + tren2);

		System.out.println();
		System.out.println("Agregar Vagones");
		System.out.println(emp.agregarVagones(tren1, 5, TipoVagon.MEDIUM));
		System.out.println(emp.agregarVagones(tren1, 7, TipoVagon.LARGE));
		System.out.println(emp.agregarVagones(tren2, 20, TipoVagon.SMALL));
		System.out.println(emp.agregarVagones(tren2, 20, TipoVagon.MEDIUM));
		System.out.println(emp.agregarVagones(999, 20, TipoVagon.LARGE));

		System.out.println();
		System.out.println("Cargar Tren");
		System.out.println(emp.cargarTren(tren1, 165));
		System.out.println(emp.cargarTren(tren1, 200));
		System.out.println(emp.cargarTren(tren2, 240));
		System.out.println(emp.cargarTren(tren2, 1000));
		System.out.println(emp.cargarTren(999, 10));
		
		System.out.println();
		System.out.println("Sacar Vagones");
		System.out.println(emp.sacarVagonesVacios(1));
		System.out.println(emp.sacarVagonesVacios(1));

		System.out.println();
		emp.listarCapacidadTrenes();
	}

}
