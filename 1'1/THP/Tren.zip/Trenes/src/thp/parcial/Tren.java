package thp.parcial;

import java.util.ArrayList;

public class Tren {
	private static final int LARGO_MAXIMO = 30;
	
	private int nroTren;
	private ArrayList<Vagon> vagones;
	
	public Tren(int nroTren) {
		this.nroTren = nroTren;
		this.vagones = new ArrayList<>();
	}
	
	public boolean agregarVagones(int cantidad, TipoVagon tipo) {
		boolean pudoAgregar = false;
		if (cantidad > 0 && vagones.size() + cantidad <= LARGO_MAXIMO) {
			for (int i = 1 ; i <= cantidad ; i++) {
				vagones.add(new Vagon(tipo));
			}
			pudoAgregar = true;
		}
		return pudoAgregar;
	}
	
	public int eliminarVagonesVacios() {
		int eliminados = 0;
		int index = 0;
		while (index < vagones.size()) {
			if (vagones.get(index).estaVacio()) {
				vagones.remove(index);
				eliminados++;
			}
			else {
				index++;
			}
		}		
		return eliminados;
	}
	
	public int getNroTren() {
		return nroTren;
	}
	
	public double capacidadTotal() {
		double capacidadTotal = 0;
		for (Vagon vagon: vagones) {
			capacidadTotal += vagon.getCapacidad();
		}
		return capacidadTotal;
	}

	public double espacioLibre() {
		double capacidadLibre = 0;
		for (Vagon vagon: vagones) {
			capacidadLibre += vagon.espacioLibre();
		}
		return capacidadLibre;
	}
	
	// llena el tren y devuelve lo que no pudo cargar
	public double cargarVagones(double cantidadTrigo) {
		int index = 0;
		while (index < vagones.size() && cantidadTrigo > 0) {
			cantidadTrigo = vagones.get(index).cargarTrigo(cantidadTrigo);
			index++;
		}
		return cantidadTrigo;
	}
	
	
}
