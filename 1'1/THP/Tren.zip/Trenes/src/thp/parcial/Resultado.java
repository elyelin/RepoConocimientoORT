package thp.parcial;

public enum Resultado {
	CANT_VAGONES_INVALIDA,
	NO_EXISTE_TREN,
	AGREGADO_OK
}
