package thp.parcial;

public enum TipoVagon {
	SMALL, MEDIUM, LARGE
}
