package thp.parcial;

public class Vagon {
	// private static final double TOLERANCIA = 0.00001d;
	
	private TipoVagon tipo;
	private double capacidad;
	private double carga;
	
	public Vagon(TipoVagon tipo) {
		this.tipo = tipo;
		this.setCapacidad();
		this.carga = 0;
	}
	
	private void setCapacidad() {
		capacidad = 0;
		switch (tipo) {
		case SMALL:
			capacidad = 30;
			break;
		case MEDIUM:
			capacidad = 40;
			break;
		case LARGE:
			capacidad = 50;
			break;
		}
	}
	
	public double getCapacidad() {
		return capacidad;
	}
	
	public double espacioLibre() {
		return capacidad - carga;
	}
	
	public boolean estaVacio() {
		return carga == 0;
		// return Math.abs(carga) < TOLERANCIA;  ->  forma correcta de comparar doubles
	}
	
	public boolean estaLleno() {
		return carga == capacidad;
		// return Math.abs(carga - capacidad) < TOLERANCIA;  ->  forma correcta de comparar doubles
	}

	// llena el vag�n y devuelve lo que no pudo cargar
	public double cargarTrigo(double cantidadTrigo) {
		double cargado = 0;
		if (cantidadTrigo > 0 && !estaLleno()) {
			// cargado = Math.min(cantidadTrigo, espacioLibre());
			if (cantidadTrigo < espacioLibre()) {
				cargado = cantidadTrigo;
			} else {
				cargado = espacioLibre();
			}
			this.carga += cargado;
		}
		return cantidadTrigo - cargado;
	}
}
