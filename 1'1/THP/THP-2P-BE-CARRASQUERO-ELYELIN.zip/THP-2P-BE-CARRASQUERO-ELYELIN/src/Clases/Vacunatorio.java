package Clases;

import java.util.ArrayList;

public class Vacunatorio {
	private int ultimoNumSerie;
	private String nombre;
	private Marca marca;
	private ArrayList<Vacuna> vacunasDisponibles;

	public Vacunatorio(String nombre, Marca marca, int cantidad) {
		this.nombre = nombre;
		this.marca = marca;
		this.vacunasDisponibles = new ArrayList<>();
		agregarLote(cantidad);
	}

	public void agregarLote(int cantidad) {
		for (int i = 0; i < cantidad; i++) {
		vacunasDisponibles.add(new Vacuna(marca, ultimoNumSerie++));
		}
	}

	public Vacuna darVacuna() {
		Vacuna v = this.vacunasDisponibles.get(0);
		this.vacunasDisponibles.remove(v);
		return v;
	}

	public String getNombre() {
		return nombre;
	}

	public Marca getMarca() {
		return this.marca;
	}

	public int cantidadDisponible() {
		return this.vacunasDisponibles.size();
	}

	@Override
	public String toString() {
		return "Vacunatorio [ultimoNumSerie=" + ultimoNumSerie + ", nombre=" + nombre + ", marca=" + marca
				+ ", vacunasDisponibles=" + vacunasDisponibles + "]";
	}

}
