package Clases;

public class Vacuna {
	private int nroSerie;
	private Marca marca;

	public Vacuna(Marca m, int nro) {
		this.marca = m;
		this.nroSerie = nro;
	}

	public Marca getMarca() {
		return marca;
	}

	@Override
	public String toString() {
		return "Vacuna [nroSerie=" + nroSerie + ", marca=" + marca + "]";
	}
}
