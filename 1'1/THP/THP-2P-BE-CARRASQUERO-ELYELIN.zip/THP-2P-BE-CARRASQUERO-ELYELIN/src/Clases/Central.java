package Clases;

import java.util.ArrayList;

public class Central {
	private ArrayList<Persona> personasEmpadronadas;
	private ArrayList<Persona> personasVacunacioCompleta;
	private ArrayList<Vacunatorio> vacunatorios;
	
	public Central() {
		this.personasEmpadronadas = new ArrayList<Persona>();
		this.personasVacunacioCompleta = new ArrayList<Persona>();
		this.vacunatorios = new ArrayList<Vacunatorio>();
	}

	public boolean agregarVacunatorio(String nombre, Marca marca, int cantidad) {
		boolean salida = false;

		if (buscarVacunatorio(nombre) == null) {
			vacunatorios.add(new Vacunatorio(nombre, marca, cantidad));
			salida = true;
		}
		return salida;
	}

	private Vacunatorio buscarVacunatorio(String nombre) {
		int i = 0;
		Vacunatorio v = null;
		while (i < vacunatorios.size() && vacunatorios.get(i).getNombre() != nombre) {
			i++;
		}
		if (i < vacunatorios.size()) {
			v = vacunatorios.get(i);
		}
		return v;
	}

	public boolean empadronarPersona(int dni) {
		boolean salida = false;

		Persona perEmpa = buscarPersona(dni, personasEmpadronadas);
		Persona perVacuComple = buscarPersona(dni, personasVacunacioCompleta);

		if (perEmpa == null && perVacuComple == null) {
			personasEmpadronadas.add(new Persona(dni));
			salida = true;
		}
		return salida;
	}


	private Persona buscarPersona(int dni, ArrayList<Persona> arrayABuscar) {
		int i = 0;
		Persona p = null;

		while (i < arrayABuscar.size() && arrayABuscar.get(i).getDni() != dni) {
			i++;
		}
		if (i < arrayABuscar.size()) {
			p = arrayABuscar.get(i);
		}
		return p;
	}

	public void mostrarVacunatoriosDisponibles(int dni) {
		Persona p = buscarPersona(dni, personasEmpadronadas);

		if (p != null) {
			System.out.println("Vacunatorios disponibles para: " + p.toString());

				for (Vacunatorio v : vacunatorios) {
					// if (p.cantidadDosis() < 0) {
					if (v.cantidadDisponible() > 0) {
						if (p.cantidadDosis() == 0) {
							System.out.println(v.toString());
						} else if (p.marcaVacuna() == v.getMarca()) {
							System.out.println(v.toString());
						}
					}
			}
		} else {
			System.out.println("Dni invalido");
		}
	}



	public Resultado vacunar(int dni, String vacunatorio) {
		Resultado r = Resultado.VACUNA_NO_DISPONIBLE;
		Persona p = buscarPersona(dni, personasEmpadronadas);
		Vacunatorio v = buscarVacunatorio(vacunatorio);

		if (p != null) {
			if (v != null) {
				if (p.cantidadDosis() < 2) {

					if (p.cantidadDosis() == 0 || v.getMarca() == p.marcaVacuna()) {
						p.agregarVacuna(v.darVacuna());
						r = Resultado.VACUNACION_OK;
					}

				} else {
					this.personasVacunacioCompleta.add(p);
					r = Resultado.VACUNACION_COMPLETA;
				}
			} else {
				r = Resultado.VACUNATORIO_INEXISTENTE;
			}
		} else {
			r = Resultado.DNI_INVALIDO;
		}

		return r;
	}

}
