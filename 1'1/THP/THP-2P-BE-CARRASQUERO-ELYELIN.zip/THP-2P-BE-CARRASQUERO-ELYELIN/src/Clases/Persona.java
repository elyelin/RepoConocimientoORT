package Clases;

import java.util.ArrayList;

public class Persona {
	private int dni;
	private ArrayList<Vacuna> vacunasAplicadas;

	public Persona(int dni) {
		this.dni = dni;
		vacunasAplicadas = new ArrayList<Vacuna>();
	}

	public int getDni() {
		return dni;
	}

	public int cantidadDosis() {
		return this.vacunasAplicadas.size();
	}

	public void agregarVacuna(Vacuna vacuna) {
		vacunasAplicadas.add(vacuna);
	}

	public boolean puedeVacunarse() {
		boolean salida = false;
		if (vacunasAplicadas.isEmpty()) {
			salida = true;
		}
		return salida;
	}

	public Marca marcaVacuna() {
		// me devuelve la marca de la primera vacuna
		return vacunasAplicadas.get(0).getMarca();
	}

	@Override
	public String toString() {
		return "Persona [dni=" + dni + ", vacunasAplicadas=" + vacunasAplicadas + "]";
	}

}
