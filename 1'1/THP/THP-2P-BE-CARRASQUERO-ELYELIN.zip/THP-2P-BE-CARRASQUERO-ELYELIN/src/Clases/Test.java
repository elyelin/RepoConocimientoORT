package Clases;

public class Test {

	public static void main(String[] args) {
		Central crisisEpidemiologica = new Central();

		System.out.println(crisisEpidemiologica.agregarVacunatorio("Rural", Marca.PFIZER, 5));
		System.out.println(crisisEpidemiologica.agregarVacunatorio("Centro Islamico", Marca.MODERNA, 5));
		System.out.println(crisisEpidemiologica.agregarVacunatorio("River", Marca.SPUTNIK, 5));
		System.out.println(crisisEpidemiologica.agregarVacunatorio("Rural", Marca.PFIZER, 5));

		System.out.println("------------------");

		System.out.println(crisisEpidemiologica.empadronarPersona(40111222));
		System.out.println(crisisEpidemiologica.empadronarPersona(40111222));
		System.out.println(crisisEpidemiologica.empadronarPersona(42333444));

		System.out.println("------------------");

		crisisEpidemiologica.mostrarVacunatoriosDisponibles(40111222);

		System.out.println(crisisEpidemiologica.vacunar(40111222, "Rural"));

		crisisEpidemiologica.mostrarVacunatoriosDisponibles(40111222);

		System.out.println(crisisEpidemiologica.vacunar(40111222, "Rural"));

		crisisEpidemiologica.mostrarVacunatoriosDisponibles(40111222);

		System.out.println(crisisEpidemiologica.vacunar(40111222, "Centro islamico"));

		System.out.println(crisisEpidemiologica.vacunar(40111222, "River"));

		System.out.println(crisisEpidemiologica.vacunar(99999999, "River"));

		System.out.println(crisisEpidemiologica.vacunar(42333444, "Boca"));

	}

}
