package Clases;

public enum Marca {
	PFIZER, MODERNA, SPUTNIK
}
