package ar.edu.ort.thp.tp3.ej6;

public enum Categoria {
	GRATUITO, ESTANDAR, PREMIUM
}
