package ar.edu.ort.thp.tp3.ej10;

public enum Dificultad {
	PRINCIPIANTE, AVANZADO, AS_DEL_VOLANTE
}
