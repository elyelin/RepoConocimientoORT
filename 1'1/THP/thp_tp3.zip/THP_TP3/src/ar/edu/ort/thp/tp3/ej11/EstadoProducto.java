package ar.edu.ort.thp.tp3.ej11;

public enum EstadoProducto {
	NO_ENCONTRADO, PARA_DESCARTE, FRESCO
}
