package ar.edu.ort.thp.tp3.ej7;

public enum ResultadoRegistracion {
	TURNO_CONFIRMADO, ERROR_TURNOS_COMPLETOS, ERROR_YA_TIENE_TURNO
}
