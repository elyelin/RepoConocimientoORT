package ar.edu.ort.thp.tp3.ej5;

public enum ResulAlta {
	CLIENTE_EXISTENTE, CLIENTE_DEUDOR, ALTA_OK
}