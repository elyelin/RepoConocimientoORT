package ar.edu.ort.thp.tp3.ej4;

public class Collar {

	private String chapita;
	
	public Collar(String chapita) {
		setChapita(chapita);
	}
	
	private void setChapita(String chapita) {
		this.chapita = chapita;
	}

	public String getChapita() {
		return chapita;
	}

}

