package ar.edu.ort.thp.tp3.ej10;

public class Vuelta {
	private double segundos;
	
	public Vuelta(double segundos) {
		this.segundos = segundos;
	}
	
	public double getSegundos() {
		return segundos;
	}

}