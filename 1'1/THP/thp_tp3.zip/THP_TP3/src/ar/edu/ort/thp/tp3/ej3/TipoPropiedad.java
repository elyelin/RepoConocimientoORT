package ar.edu.ort.thp.tp3.ej3;

public enum TipoPropiedad {
	DEPARTAMENTO, CASA, PH
}
