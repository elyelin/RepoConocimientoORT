package ar.edu.ort.thp.tp3.ej5;

public enum TipoServicio {
	STANDARD, PREMIUM
}