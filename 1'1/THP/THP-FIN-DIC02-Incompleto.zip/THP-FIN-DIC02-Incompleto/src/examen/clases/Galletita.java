package examen.clases;

public class Galletita {
	private static final double GRAMOS_DESEADOS = 10;
	private static final double GRAMOS_ACEPTABLES = GRAMOS_DESEADOS / 2;
	private static final double PORC_COBERTURA_VALIDO = 98;
	private double gramos;
	private boolean entera;
	private double porcentajeCobertura;
	private Calidad calidad;
	
	public Galletita() {
		// TODO implementar.
	}

	private void calcularCobertura() {
		// TODO implementar.
	}

	public boolean estaEntera() {
		return entera;
	}

	private void evaluarCalidad() {
		// TODO implementar.
	}

	public Calidad getCalidad() {
		return calidad;
	}

	public double getGramos() {
		return gramos;
	}

	private void obtenerEntereza() {
		// TODO implementar.
	}

	@Override
	public String toString() {
		return "Galletita [gramos=" + gramos + ", entera=" + entera + ", calidad=" + calidad + "]";
	}

}