package examen.clases;

public class Bolsa {
	private double pesoEstimado;
	private double pesoNeto;
	// TODO completar ... aca quedan las galletitas de la bolsa;

	public Bolsa(int pesoEstimado) {
		// TODO implementar
	}

	public boolean estaLlena() {
		// TODO implementar, el valor devuelto es solo para que compile
		return false;
	}

	public void agregar(Galletita galletita) {
		// TODO implementar
	}

	public boolean estaVacia() {
		// TODO implementar, el valor devuelto es solo para que compile
		return false;
	}

	public Galletita extraer() {
		// TODO implementar, el valor devuelto es solo para que compile
		return null;
	}

	public double getPesoNeto() {
		return pesoNeto;
	}

}