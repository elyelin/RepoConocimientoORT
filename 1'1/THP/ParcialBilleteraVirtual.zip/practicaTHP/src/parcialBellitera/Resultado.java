package parcialBellitera;

public enum Resultado {
	TRANSACCION_OK, SIN_TARJETA_PARA_COMPRA, USUARIO_INEXISTENTE, ERROR
}
