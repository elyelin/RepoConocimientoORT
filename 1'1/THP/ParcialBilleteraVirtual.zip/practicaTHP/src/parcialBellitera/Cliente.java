package parcialBellitera;

import java.util.ArrayList;

public class Cliente {
	private String dni;
	private ArrayList<Tarjeta> tarjetas;
	private int cantCompras;

	public Cliente(String dni) {
		this.setDni(dni);
		this.setCantCompras(0);
		tarjetas = new ArrayList<>();
	}

	public boolean agregarTarjeta(String numero, String nombre, double monto) {
		boolean pudo = false;
		Tarjeta t = buscarTarjeta(numero);
		if (t == null) {
			tarjetas.add(new Tarjeta(numero, nombre, monto));
			pudo = true;
		}
		return pudo;
	}

	public boolean comprar(double monto) {
		boolean pudo = false;
		int i = 0;

		while (i < tarjetas.size() && tarjetas.get(i).getDisponible() >= monto) {
			i++;
		}
		if (i < tarjetas.size()) {
			tarjetas.get(i).descontar(monto);
			this.cantCompras++;
				pudo = true;
			}

		return pudo;
	}

	public void tarjetasConDisponible(double monto) {
		// se quiere visualizar todas las tarjetas que tengan saldo disponible
		// muestra la información de las tarjetas que puede realizar dicha compra.
		for (Tarjeta tarjeta : tarjetas) {
			if (tarjeta.getDisponible() >= monto) {
				System.out.println("Tarjeta [numero=" + tarjeta.getNumero() + ", marca=" + tarjeta.getNombre()
						+ ", disponible=" + tarjeta.getDisponible() + "]");
			}

		}

	}

	private Tarjeta buscarTarjeta(String numero) {
		int i = 0;
		Tarjeta c = null;
		while (i < tarjetas.size() && tarjetas.get(i).getNumero() != numero) {
			i++;
		}
		if (i < tarjetas.size()) {
			c = tarjetas.get(i);
		}
		return c;
	}
	public String getDni() {
		return dni;
	}

	private void setDni(String dni) {
		this.dni = dni;
	}

	public int getCantCompras() {
		return cantCompras;
	}

	private void setCantCompras(int cantCompras) {
		this.cantCompras = cantCompras;
	}

}
