package parcialBellitera;

import java.util.ArrayList;

public class Billetera {
	private ArrayList<Cliente> clientes;

	public Billetera() {
		clientes = new ArrayList<Cliente>();
	}

	public boolean agregarCliente(String dni) {
		Cliente c = buscarCliente(dni);
		boolean conf = false;

		if (c == null) {
			clientes.add(new Cliente(dni));
			conf = true;
		}
		return conf;
	}

	private Cliente buscarCliente(String dni) {
		int i = 0;
		Cliente c = null;
		while (i < clientes.size() && clientes.get(i).getDni() != dni) {
			i++;
		}
		if (i < clientes.size()) {
			c = clientes.get(i);
		}
		return c;
	}

	public boolean registrarTarjeta(String dni, String numero, String nombre, double monto) {
		boolean pudo = false;
		Cliente c = buscarCliente(dni);
		if (c != null && c.agregarTarjeta(numero, nombre, monto)) {
			pudo = true;
		}
		return pudo;
	}

	public void mostrarTarjetasPuedenComprar(String dni, double monto) {
		// muestra la información de las tarjetas que puede realizar dicha compra.
		Cliente c = buscarCliente(dni);
		c.tarjetasConDisponible(monto);
	}

	public void mostrarTarjetasConSaldo() {
		// Lista la información de todos los usuarios registrados en la app De cada
		// usuario además, se quiere visualizar todas las tarjetas que tengan saldo
		// disponible
		for (Cliente cliente : clientes) {
			System.out.println("Usuario:" + cliente.getDni());
			cliente.tarjetasConDisponible(0);
		}
	}

	public ArrayList<String> obtenerCompras() {
		ArrayList<String> result = new ArrayList<String>();

		for (Cliente c : clientes) {
			result.add("Usuario: " + c.getDni() + " - Cantidad de compras: " + c.getCantCompras());
		}
		return result;
	}

	public Resultado realizarCompra(String dni, double monto, int cuotas) {
		// . Debe utilizar la tarjeta que MÁS SALDO tenga, y que pueda abonar ese
	// monto. Retorna uno de los siguientes resultados:
	// • TRANSACCION_OK, si pudo realizar la acción
	// • SIN_TARJETA_PARA_COMPRA, cuando no exista alguna tarjeta con monto
	// suficiente para realizar dicha compra.
	// • USUARIO_INEXISTENTE, cuando el usuario indicado no exista en la aplicación
	// • ERROR, cuando el monto y/o la cantidad de cuotas especificadas sean
	// erróneas
	Resultado res = Resultado.ERROR;
	Cliente c = buscarCliente(dni);
		if (c != null ) {
			// realiza la compra actualizando el saldo de la tarjeta y contando dica compra
			// eso lo hace el metodo comprar de cliente
			if(c.comprar(monto)) {
				res = Resultado.TRANSACCION_OK;
			} else {
				res = Resultado.SIN_TARJETA_PARA_COMPRA;
			}
		} else {
			res = Resultado.USUARIO_INEXISTENTE;
		}
		return res;
	}

	public void comprar(String dni, double monto, int cuotas) {
	// muestra el resultado de la operación. En caso de que la transacción sea realizada, además informa cuánto se deberá abonar por cada cuota.
	// 40000000 hace una compra de 15000 en 3 cuotas
	// Compra realizada por 40000000
	// Monto Compra: 15000 - coutas 3
	// Monto por Cuota:5000
	Cliente c = buscarCliente(dni);

	if (c != null && c.comprar(monto)) {
		System.out.println("El usuario dni " + dni + " hace una compra de " + monto + " en " + cuotas + " cuotas");
		System.out.println("Compra realizada por " + dni);
		System.out.println("Monto de compra: " + monto + " - cuotas " + cuotas);
		int m = (int) (monto / cuotas);
		System.out.println("Monto por cuotas: " + m);
	}
}
}
