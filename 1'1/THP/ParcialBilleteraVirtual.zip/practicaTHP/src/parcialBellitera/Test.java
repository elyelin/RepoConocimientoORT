package parcialBellitera;

public class Test {

	public static void main(String[] args) {
		/*
		 * Agregamos el usuario 30000000 : true Agregamos el usuario 40000000 : true
		 * Registramos tarjeta al usuario dni 30000000 numero 2345789000 marca INSTICARD
		 * disponible 50000.0 : true Registramos tarjeta al usuario dni 30000000 numero
		 * 4444455555 marca MONTACARD disponible 1000.0 : true Registramos tarjeta al
		 * usuario dni 35000000 numero 1234567890 marca INSTICARD disponible 100000.0 :
		 * false Registramos tarjeta al usuario dni 40000000 numero 6666644444 marca
		 * YATAYPLUS disponible 100000.0 : true Registramos tarjeta al usuario dni
		 * 40000000 numero 9999988888 marca INSTICARD disponible 0.0 : true Registramos
		 * tarjeta al usuario dni 40000000 numero 6666644444 marca disponibl 100000.0
		 * :false
		 * 
		 * Vemos que tarjetas del usuario dni 3000000 pueden hacer una compra de 5000
		 * 
		 * Lista de tarjetas ok de 30000000 Tarjeta [numero=2345789000, marca=INSTICARD,
		 * disponible=50000.0]
		 * 
		 * El usuario dni 40000000 hace una compra de 15000 en 3 cuotas Compra realizada
		 * por 40000000 Monto Compra: 15000 - coutas 3 Monto por Cuota:5000 Listamos los
		 * usuarios y  la cantidad de compras que realizaron Usuario: 30000000 - Cant
		 * Compras: 0 Usuario: 40000000 - Cant Compras: 1 Ahora listamos las tarjetas
		 * con saldo de todos los usuarios Tarjetas de 30000000 Tarjeta
		 * [numero=2345789000, marca=INSTICARD, disponible=50000.0] Tarjeta
		 * [numero=4444455555, marca=MONTACARD, disponible=1000.0] Tarjetas de 40000000
		 * Tarjeta [numero=6666644444, marca=YATAYPLUS, disponible=85000.0]
		 */
		Billetera mood = new Billetera();
		System.out.println("Agregamos los usuario");
		System.out.println(mood.agregarCliente("30000000"));
		System.out.println(mood.agregarCliente("40000000"));
		System.out.println("Registramos tarjetas a los usuarios");
		System.out.println(mood.registrarTarjeta("30000000", "2345789000", "INSTICARD", 50000.0));
		System.out.println(mood.registrarTarjeta("30000000", "4444455555", "MONTACARD", 1000.0));
		System.out.println(mood.registrarTarjeta("35000000", "1234567890", "INSTICARD", 100000.0));
		System.out.println(mood.registrarTarjeta("40000000", "6666644444", "YATAYPLUS", 100000.0));
		System.out.println(mood.registrarTarjeta("40000000", "9999988888", "INSTICARD", 0.0));
		System.out.println(mood.registrarTarjeta("40000000", "6666644444", "YATAYPLUS", 100000.0));
		System.out.println("Vemos que tarjetas del usuario dni 3000000 pueden hacer una compra de 5000");
		mood.mostrarTarjetasPuedenComprar("30000000", 500);

		mood.comprar("40000000", 15000, 3);
		System.out.println("Listamos usuarios y cantidad de compras");
		System.out.println(mood.obtenerCompras());
		System.out.println("Listamos las tarjetas con saldo de todos los usuarios");
		mood.mostrarTarjetasConSaldo();

	}

}
