package parcialBellitera;

public class Tarjeta {
	private String numero;
	private String nombre;
	private double disponible;

	public Tarjeta(String numero, String nombre, double monto) {
		setNumero(numero);
		setNombre(nombre);
		setDisponible(monto);
	}

	public void descontar(double monto) {
		this.disponible = disponible - monto;
	}

	public String getNumero() {
		return numero;
	}

	private void setNumero(String numero) {
		this.numero = numero;
	}

	public double getDisponible() {
		return disponible;
	}

	private void setDisponible(double disponible) {
		if (disponible >= 0) {
			this.disponible = disponible;
		}
	}

	public String getNombre() {
		return nombre;
	}

	private void setNombre(String nombre) {
		this.nombre = nombre;
	}

}
